//
//  ResultsViewController.swift
//  BubbleSearch
//
//  Created by Jean Marc LIRON on 13/10/2014.
//  Copyright (c) 2014 Jean Marc LIRON. All rights reserved.
//

import UIKit

class ResultsViewController: UIViewController {
    

    /*@IBAction func fromResultsToSettings(sender: UIButton) { self.performSegueWithIdentifier("presentSettingsFromResults", sender: self)
    }*/
    @IBAction func fromResultsToBubbles(sender: UIButton) {
        //self.performSegueWithIdentifier("presentBubblesFromResults", sender: self)
        //self.navigationController?.popViewControllerAnimated(true)
       self.navigationController?.popViewControllerAnimated(true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

