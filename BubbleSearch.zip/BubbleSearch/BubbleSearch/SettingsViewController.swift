//
//  SettingsViewController.swift
//  BubbleSearch
//
//  Created by Jean Marc LIRON on 27/10/2014.
//  Copyright (c) 2014 Jean Marc LIRON. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {
    
    
    @IBAction func goToBubblesFromSettings(sender: UIButton) {
        self.navigationController?.popViewControllerAnimated(true)
        
        
        //self.performSegueWithIdentifier("presentBubblesFromSettings", sender: self)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}