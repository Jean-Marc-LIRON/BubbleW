//
//  BubbleViewController.swift
//  BubbleSearch
//
//  Created by Jean Marc LIRON on 03/11/2014.
//  Copyright (c) 2014 Jean Marc LIRON. All rights reserved.
//

import UIKit

class BubbleViewController: UIViewController {
    
    
    @IBOutlet weak var btnBubble: UIButton!
    
    
   @IBAction func bubbleTouchUpInside(sender: AnyObject) {
           println("Hi Jean-Marc, You Just Pressed a blue Bubble for the \(btnBubble.tag)th time!")
        btnBubble.tag++
        
        btnBubble.setTitle("Where : Morlaix - France - and surrounding area \(btnBubble.tag) ", forState: UIControlState.Normal)
    }
    
    
    
    @IBAction func bubbleTouchDragExit(sender: UIButton) {
        btnBubble.setTitle("You Just dragged this blue Bubble for the \(btnBubble.tag)th time!", forState: UIControlState.Normal)
        btnBubble.tag++
    }
    
    
    
    
    @IBAction func goToSettings(sender: UIButton) {
        self.performSegueWithIdentifier("presentSettings", sender: self)
    }
    
    
    @IBAction func goToResultsPressed(sender: AnyObject) {
        self.performSegueWithIdentifier("pushResultsVC", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}